package com.example.mochiauto

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.roundToInt

/** Draws the face with the same renderer the car uses. */
class FacePreview(context: Context) : View(context) {
    private val renderer = MochiFaceRenderer()
    private val area = Rect()
    private var last = System.nanoTime()

    @Volatile var cfg = MochiConfig()
    /** 0 idle, 1 accelerate, 2 brake, 3 left, 4 right, -1 live sensors */
    var scenario = 0
    var engine: MotionEngine? = null

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        last = now
        area.set(0, 0, width, height)

        var st = MochiState.IDLE
        var lat = 0f
        var lon = 0f
        when (scenario) {
            1 -> { st = MochiState.ACCELERATING; lon = 4f }
            2 -> { st = MochiState.BRAKING; lon = -5f }
            3 -> { st = MochiState.TURNING_LEFT; lat = -4f }
            4 -> { st = MochiState.TURNING_RIGHT; lat = 4f }
            -1 -> engine?.let { st = it.state; lat = it.lat; lon = it.lon }
        }
        renderer.draw(canvas, area, st, lat, lon, dt, cfg)
        postInvalidateOnAnimation()
    }
}

class MainActivity : Activity() {

    private var cfg = MochiConfig()
    private lateinit var preview: FacePreview
    private lateinit var engine: MotionEngine
    private lateinit var root: LinearLayout

    private val eyeColors = intArrayOf(
        Color.WHITE, 0xFF00E5FF.toInt(), 0xFF76FF03.toInt(), 0xFFFFC107.toInt(), 0xFFFF80AB.toInt()
    )
    private val blushColors = intArrayOf(
        0xFFFF7896.toInt(), 0xFFFF5252.toInt(), 0xFFFF9800.toInt(), 0xFFCE93D8.toInt(), 0xFF80D8FF.toInt()
    )
    private val bgColors = intArrayOf(
        Color.BLACK, 0xFF0A1030.toInt(), 0xFF1A0A1F.toInt(), 0xFF06210F.toInt(), 0xFF2B0A0A.toInt()
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = MochiPrefs.load(this)
        engine = MotionEngine(applicationContext)
        engine.config = cfg

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.BLACK) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        scroll.addView(root)
        setContentView(scroll)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (preview.scenario == -1) engine.start()
    }

    override fun onPause() {
        super.onPause()
        engine.stop()
    }

    private fun change(f: (MochiConfig) -> MochiConfig) {
        cfg = f(cfg)
        MochiPrefs.save(this, cfg)
        preview.cfg = cfg
        engine.config = cfg
    }

    // ---------- UI ----------

    private fun build() {
        add(text("Mochi Auto", 26f, Color.WHITE))
        add(text("Changes apply instantly, including on the car screen.", 13f, 0xFF999999.toInt()))

        preview = FacePreview(this).apply { cfg = this@MainActivity.cfg; engine = this@MainActivity.engine }
        add(preview, 14, dp(220))

        chips("Preview", listOf("Idle", "Accel", "Brake", "Left", "Right", "Live"), 0) { i ->
            if (i == 5) {
                preview.scenario = -1
                engine.start()
            } else {
                preview.scenario = i
                engine.stop()
            }
        }
        add(text("Live: move the phone, shake it along the screen's front/back axis for accelerate/brake.", 12f, 0xFF777777.toInt()))
        add(text("Motion sensor: ${engine.status}", 12f, if (engine.status == "none found") Color.RED else 0xFF77DD77.toInt()))

        section("Face")
        chips("Eyes", listOf("Round", "Pixel", "Tall", "Wide"), cfg.eyeStyle) { i -> change { it.copy(eyeStyle = i) } }
        chips("Mouth", listOf("None", "Smile", "Cat"), cfg.mouthStyle) { i -> change { it.copy(mouthStyle = i) } }
        swatches("Eye color", eyeColors, cfg.eyeColor) { c -> change { it.copy(eyeColor = c) } }
        swatches("Blush color", blushColors, cfg.blushColor) { c -> change { it.copy(blushColor = c) } }
        swatches("Background", bgColors, cfg.bgColor) { c -> change { it.copy(bgColor = c) } }
        toggle("Show blush", cfg.showBlush) { b -> change { it.copy(showBlush = b) } }

        section("Vehicle type")
        val desc = text(Vehicle.values()[cfg.vehicle.coerceIn(0, 3)].desc, 12f, 0xFF999999.toInt())
        chips("Profile", Vehicle.values().map { it.label }, cfg.vehicle) { i ->
            desc.text = Vehicle.values()[i].desc
            change { it.copy(vehicle = i) }
        }
        add(desc, 4)

        section("Animation")
        slider("Animation speed", 0.5f, 2f, cfg.animSpeed) { v -> change { it.copy(animSpeed = v) } }
        slider("Lean / tilt", 0f, 2f, cfg.lean) { v -> change { it.copy(lean = v) } }
        slider("Idle bobbing", 0f, 2f, cfg.bob) { v -> change { it.copy(bob = v) } }
        slider("Blink rate", 0.5f, 2f, cfg.blinkRate) { v -> change { it.copy(blinkRate = v) } }
        slider("Sensitivity", 0.5f, 2f, cfg.sensitivity) { v -> change { it.copy(sensitivity = v) } }
        toggle("Shake when braking hard", cfg.shake) { b -> change { it.copy(shake = b) } }

        section("Phone mounting")
        toggle("Phone upright (portrait, screen facing you)", cfg.upright) { b -> change { it.copy(upright = b) } }
        toggle("Swap left / right", cfg.invertLat) { b -> change { it.copy(invertLat = b) } }
        toggle("Swap forward / back", cfg.invertLon) { b -> change { it.copy(invertLon = b) } }

        val reset = Button(this).apply {
            text = "Reset to defaults"
            setOnClickListener {
                MochiPrefs.save(this@MainActivity, MochiConfig())
                recreate()
            }
        }
        add(reset, 24)

        add(
            text(
                "Car setup: Android Auto settings > tap Version 10 times > Developer settings > " +
                    "Unknown sources. Reconnect, then look for Mochi Auto in the car's app grid.",
                12f, 0xFF777777.toInt()
            ), 16
        )
    }

    private fun add(v: View, topDp: Int = 0, heightPx: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
        root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heightPx).apply {
            topMargin = dp(topDp)
        })
    }

    private fun text(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
    }

    private fun section(title: String) {
        add(text(title, 18f, Color.WHITE), 26)
    }

    private fun paintChip(v: View, on: Boolean) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(if (on) 0xFF3D5AFE.toInt() else 0xFF222222.toInt())
        }
    }

    private fun chips(label: String, options: List<String>, selected: Int, onPick: (Int) -> Unit) {
        add(text(label, 13f, 0xFFAAAAAA.toInt()), 14)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        options.forEachIndexed { i, name ->
            val tv = TextView(this).apply {
                text = name
                textSize = 13f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
            }
            paintChip(tv, i == selected)
            tv.setOnClickListener {
                views.forEachIndexed { j, other -> paintChip(other, j == i) }
                onPick(i)
            }
            views.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            })
        }
        add(row, 6)
    }

    private fun swatches(label: String, colors: IntArray, selected: Int, onPick: (Int) -> Unit) {
        add(text(label, 13f, 0xFFAAAAAA.toInt()), 14)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<View>()
        fun paint(v: View, color: Int, on: Boolean) {
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(3), if (on) 0xFF3D5AFE.toInt() else 0xFF444444.toInt())
            }
        }
        colors.forEachIndexed { i, c ->
            val v = View(this)
            paint(v, c, c == selected)
            v.setOnClickListener {
                views.forEachIndexed { j, other -> paint(other, colors[j], j == i) }
                onPick(c)
            }
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) })
        }
        add(row, 6)
    }

    private fun slider(label: String, min: Float, max: Float, value: Float, onChange: (Float) -> Unit) {
        val tv = text("$label: ${String.format("%.1f", value)}", 13f, 0xFFAAAAAA.toInt())
        add(tv, 14)
        val sb = SeekBar(this).apply {
            this.max = 100
            progress = ((value - min) / (max - min) * 100f).roundToInt().coerceIn(0, 100)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = min + (max - min) * progress / 100f
                tv.text = "$label: ${String.format("%.1f", v)}"
                onChange(v)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        add(sb, 2)
    }

    private fun toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            isChecked = value
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
        add(sw, 14)
    }
}
