package com.example.mochiauto

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// ==========================================
// 1. CONFIG (shared by phone UI and car screen)
// ==========================================

enum class MochiState { IDLE, ACCELERATING, BRAKING, TURNING_LEFT, TURNING_RIGHT }

/** Vehicle profile: scales trigger thresholds and animation feel. */
enum class Vehicle(
    val label: String,
    val desc: String,
    val threshold: Float, // multiplies G thresholds (higher = harder to trigger)
    val lean: Float,      // multiplies tilt / eye shift
    val shake: Float,     // multiplies brake shiver
    val response: Float   // multiplies animation speed
) {
    SEDAN("Sedan", "Balanced, matches the default spec.", 1.0f, 1.0f, 1.0f, 1.0f),
    SPORTS("Sports", "Twitchy: triggers early, big lean, fast.", 0.8f, 1.3f, 1.2f, 1.4f),
    SUV("SUV", "A little softer and slower than a sedan.", 1.1f, 0.9f, 0.9f, 0.9f),
    TRUCK("Truck", "Heavy: needs hard inputs, slow and calm.", 1.3f, 0.6f, 0.7f, 0.6f)
}

data class MochiConfig(
    val eyeStyle: Int = 0,      // 0 round, 1 pixel, 2 tall oval, 3 wide rounded
    val mouthStyle: Int = 0,    // 0 none, 1 smile, 2 cat
    val eyeColor: Int = Color.WHITE,
    val blushColor: Int = 0xFFFF7896.toInt(),
    val bgColor: Int = Color.BLACK,
    val showBlush: Boolean = true,
    val vehicle: Int = 0,
    val animSpeed: Float = 1f,
    val lean: Float = 1f,
    val bob: Float = 1f,
    val sensitivity: Float = 1f,
    val blinkRate: Float = 1f,
    val shake: Boolean = true,
    val upright: Boolean = true,
    val invertLat: Boolean = false,
    val invertLon: Boolean = false
) {
    fun vehicleType(): Vehicle = Vehicle.values()[vehicle.coerceIn(0, Vehicle.values().size - 1)]
}

object MochiPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("mochi", Context.MODE_PRIVATE)

    fun load(c: Context): MochiConfig {
        val p = sp(c)
        val d = MochiConfig()
        return MochiConfig(
            eyeStyle = p.getInt("eyeStyle", d.eyeStyle),
            mouthStyle = p.getInt("mouthStyle", d.mouthStyle),
            eyeColor = p.getInt("eyeColor", d.eyeColor),
            blushColor = p.getInt("blushColor", d.blushColor),
            bgColor = p.getInt("bgColor", d.bgColor),
            showBlush = p.getBoolean("showBlush", d.showBlush),
            vehicle = p.getInt("vehicle", d.vehicle),
            animSpeed = p.getFloat("animSpeed", d.animSpeed),
            lean = p.getFloat("lean", d.lean),
            bob = p.getFloat("bob", d.bob),
            sensitivity = p.getFloat("sensitivity", d.sensitivity),
            blinkRate = p.getFloat("blinkRate", d.blinkRate),
            shake = p.getBoolean("shake", d.shake),
            upright = p.getBoolean("upright", d.upright),
            invertLat = p.getBoolean("invertLat", d.invertLat),
            invertLon = p.getBoolean("invertLon", d.invertLon)
        )
    }

    fun save(c: Context, m: MochiConfig) {
        sp(c).edit()
            .putInt("eyeStyle", m.eyeStyle)
            .putInt("mouthStyle", m.mouthStyle)
            .putInt("eyeColor", m.eyeColor)
            .putInt("blushColor", m.blushColor)
            .putInt("bgColor", m.bgColor)
            .putBoolean("showBlush", m.showBlush)
            .putInt("vehicle", m.vehicle)
            .putFloat("animSpeed", m.animSpeed)
            .putFloat("lean", m.lean)
            .putFloat("bob", m.bob)
            .putFloat("sensitivity", m.sensitivity)
            .putFloat("blinkRate", m.blinkRate)
            .putBoolean("shake", m.shake)
            .putBoolean("upright", m.upright)
            .putBoolean("invertLat", m.invertLat)
            .putBoolean("invertLon", m.invertLon)
            .apply()
    }

    fun register(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sp(c).registerOnSharedPreferenceChangeListener(l)

    fun unregister(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sp(c).unregisterOnSharedPreferenceChangeListener(l)
}

// ==========================================
// 2. MOTION ENGINE (sensor -> filtered G -> state)
// ==========================================

class MotionEngine(context: Context) : SensorEventListener {

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val linear: Sensor? = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val sensor: Sensor? = linear ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val fallback = linear == null

    val status: String
        get() = when {
            sensor == null -> "none found"
            fallback -> "accelerometer (fallback)"
            else -> "linear acceleration"
        }

    @Volatile var config = MochiConfig()

    /** Filtered lateral accel, + = right. */
    @Volatile var lat = 0f
        private set

    /** Filtered longitudinal accel, + = forward. */
    @Volatile var lon = 0f
        private set

    @Volatile var state = MochiState.IDLE
        private set

    private val grav = FloatArray(3)
    private var gravSeeded = false

    fun start() {
        lat = 0f
        lon = 0f
        state = MochiState.IDLE
        gravSeeded = false
        sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() {
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != sensor?.type) return
        val c = config
        val v = event.values

        var x: Float
        var fwd: Float
        if (fallback) {
            if (!gravSeeded) {
                for (i in 0..2) grav[i] = v[i]
                gravSeeded = true
            } else {
                for (i in 0..2) grav[i] = 0.98f * grav[i] + 0.02f * v[i]
            }
            x = v[0] - grav[0]
            fwd = if (c.upright) -(v[2] - grav[2]) else (v[1] - grav[1])
        } else {
            x = v[0]
            fwd = if (c.upright) -v[2] else v[1]
        }
        if (c.invertLat) x = -x
        if (c.invertLon) fwd = -fwd

        // Low-pass filter, alpha = 0.15
        lat += ALPHA * (x - lat)
        lon += ALPHA * (fwd - lon)

        // Thresholds scale with vehicle profile and sensitivity
        val k = c.vehicleType().threshold / c.sensitivity.coerceAtLeast(0.1f)
        val enterBrake = 3.5f * k
        val exitBrake = 2.0f * k
        val enterAccel = 2.5f * k
        val exitAccel = 1.5f * k
        val enterTurn = 2.5f * k
        val exitTurn = 1.5f * k

        val s = state
        state = when {
            lon < -enterBrake || (s == MochiState.BRAKING && lon < -exitBrake) -> MochiState.BRAKING
            lon > enterAccel || (s == MochiState.ACCELERATING && lon > exitAccel) -> MochiState.ACCELERATING
            lat < -enterTurn || (s == MochiState.TURNING_LEFT && lat < -exitTurn) -> MochiState.TURNING_LEFT
            lat > enterTurn || (s == MochiState.TURNING_RIGHT && lat > exitTurn) -> MochiState.TURNING_RIGHT
            else -> MochiState.IDLE
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private companion object {
        const val ALPHA = 0.15f
    }
}

// ==========================================
// 3. CAR APP SERVICE, SESSION, SCREEN
// ==========================================

class MochiCarAppService : CarAppService() {
    // Fine for sideloading; use a signature allow-list for a store release.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = MochiSession()
}

class MochiSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = MochiScreen(carContext)
}

class MochiScreen(carContext: CarContext) :
    Screen(carContext), SurfaceCallback, DefaultLifecycleObserver {

    private val appCtx: Context = carContext.applicationContext ?: carContext
    private val engine = MotionEngine(appCtx)
    private val renderer = MochiFaceRenderer()

    @Volatile private var cfg = MochiPrefs.load(appCtx)
    @Volatile private var activeSurface: Surface? = null
    @Volatile private var isRunning = false
    @Volatile private var stableArea = Rect()
    private var renderThread: Thread? = null

    // Strong reference: SharedPreferences only holds listeners weakly
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        reloadConfig()
    }

    init {
        engine.config = cfg
        lifecycle.addObserver(this)
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(this)
    }

    private fun reloadConfig() {
        cfg = MochiPrefs.load(appCtx)
        engine.config = cfg
    }

    override fun onGetTemplate(): Template {
        val exit = Action.Builder()
            .setTitle("Exit")
            .setOnClickListener { carContext.finishCarApp() }
            .build()
        return NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(exit).build())
            .build()
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        activeSurface = surfaceContainer.surface
        if (surfaceContainer.width > 0 && surfaceContainer.height > 0) {
            stableArea = Rect(0, 0, surfaceContainer.width, surfaceContainer.height)
        }
        startRenderThread()
    }

    override fun onStableAreaChanged(stableArea: Rect) {
        if (!stableArea.isEmpty) this.stableArea = Rect(stableArea)
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) { /* ignored on purpose */ }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        stopRenderThread()
        activeSurface = null
    }

    override fun onStart(owner: LifecycleOwner) {
        reloadConfig()
        MochiPrefs.register(appCtx, prefsListener)
        engine.start()
    }

    override fun onStop(owner: LifecycleOwner) {
        engine.stop()
        MochiPrefs.unregister(appCtx, prefsListener)
    }

    override fun onDestroy(owner: LifecycleOwner) {
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(null)
        stopRenderThread()
    }

    private fun startRenderThread() {
        if (isRunning) return
        isRunning = true

        renderThread = thread(name = "MochiRenderThread") {
            val frameNs = 16_666_666L
            var lastNs = System.nanoTime()
            var useSoftware = false

            while (isRunning) {
                val surface = activeSurface
                if (surface == null || !surface.isValid) {
                    try { Thread.sleep(16) } catch (_: InterruptedException) { break }
                    lastNs = System.nanoTime()
                    continue
                }

                val startNs = System.nanoTime()
                val dt = ((startNs - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                lastNs = startNs

                var canvas: Canvas? = null
                try {
                    canvas = if (!useSoftware) {
                        try {
                            surface.lockHardwareCanvas()
                        } catch (e: Exception) {
                            Log.w("Mochi", "Hardware canvas failed, using software canvas", e)
                            useSoftware = true
                            surface.lockCanvas(null)
                        }
                    } else {
                        surface.lockCanvas(null)
                    }

                    if (canvas != null) {
                        renderer.draw(canvas, stableArea, engine.state, engine.lat, engine.lon, dt, cfg)
                    }
                } catch (_: Exception) {
                    // surface torn down mid-frame
                } finally {
                    if (canvas != null) {
                        try { surface.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
                    }
                }

                val sleepNs = frameNs - (System.nanoTime() - startNs)
                if (sleepNs > 0) {
                    try {
                        Thread.sleep(sleepNs / 1_000_000L, (sleepNs % 1_000_000L).toInt())
                    } catch (_: InterruptedException) { break }
                }
            }
        }
    }

    private fun stopRenderThread() {
        isRunning = false
        renderThread?.interrupt()
        try { renderThread?.join(400) } catch (_: InterruptedException) {}
        renderThread = null
    }
}

// ==========================================
// 4. RENDERER (used by the car and the phone preview)
// ==========================================

class MochiFaceRenderer {

    private val eyeFill = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
    private val eyeStroke = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val cheekPaint = Paint().apply { isAntiAlias = true }
    private val dotPaint = Paint().apply { isAntiAlias = true }

    private val leftEyePath = Path()
    private val rightEyePath = Path()
    private val mouthPath = Path()
    private val rect = RectF()

    private var shockWeight = 0f
    private var squintWeight = 0f
    private var lookXWeight = 0f
    private var currentTilt = 0f
    private var currentDepthScale = 1f
    private var currentDepthShiftY = 0f
    private var idleTick = 0f
    private var shakeTick = 0f

    private var isBlinking = false
    private var blinkTimerSec = 3.0f
    private var blinkProgressSec = 0f
    private val blinkDurationSec = 0.18f

    private fun ease(cur: Float, target: Float, rate: Float, dt: Float): Float =
        cur + (target - cur) * (1f - exp(-rate * dt))

    private fun drawEye(c: Canvas, x: Float, y: Float, r: Float, style: Int) {
        when (style) {
            1 -> c.drawRect(x - r * 0.9f, y - r * 0.9f, x + r * 0.9f, y + r * 0.9f, eyeFill)
            2 -> {
                rect.set(x - r * 0.75f, y - r * 1.3f, x + r * 0.75f, y + r * 1.3f)
                c.drawOval(rect, eyeFill)
            }
            3 -> {
                rect.set(x - r * 1.2f, y - r * 0.85f, x + r * 1.2f, y + r * 0.85f)
                c.drawRoundRect(rect, r * 0.4f, r * 0.4f, eyeFill)
            }
            else -> c.drawCircle(x, y, r, eyeFill)
        }
    }

    fun draw(
        canvas: Canvas,
        area: Rect,
        state: MochiState,
        latG: Float,
        longG: Float,
        dt: Float,
        cfg: MochiConfig
    ) {
        val w = area.width().toFloat()
        val h = area.height().toFloat()
        if (w <= 0f || h <= 0f) return

        val veh = cfg.vehicleType()
        val sdt = dt * cfg.animSpeed * veh.response
        val leanK = cfg.lean * veh.lean

        canvas.drawColor(cfg.bgColor) // clear the whole surface
        eyeFill.color = cfg.eyeColor
        eyeStroke.color = cfg.eyeColor
        cheekPaint.color = cfg.blushColor
        dotPaint.color = cfg.bgColor

        val s = min(w, h) / 480f
        val cx = area.exactCenterX()
        val cy = area.exactCenterY()

        // Blink timer
        if (!isBlinking) {
            blinkTimerSec -= dt
            if (blinkTimerSec <= 0f) { isBlinking = true; blinkProgressSec = 0f }
        } else {
            blinkProgressSec += dt
            if (blinkProgressSec >= blinkDurationSec) {
                isBlinking = false
                blinkTimerSec = (2.5f + Random.nextFloat() * 3.0f) / cfg.blinkRate.coerceAtLeast(0.1f)
            }
        }
        val blinkFactor = if (isBlinking && shockWeight < 0.2f && squintWeight < 0.2f)
            sin(PI.toFloat() * (blinkProgressSec / blinkDurationSec)).coerceIn(0f, 1f) else 0f

        // Morph targets
        shockWeight = ease(shockWeight, if (state == MochiState.BRAKING) 1f else 0f, 14f, sdt)
        squintWeight = ease(squintWeight, if (state == MochiState.ACCELERATING) 1f else 0f, 14f, sdt)
        val lookTarget = when (state) {
            MochiState.TURNING_LEFT -> 1f
            MochiState.TURNING_RIGHT -> -1f
            else -> 0f
        }
        lookXWeight = ease(lookXWeight, lookTarget, 10f, sdt)

        // Lean back on acceleration, tilt against the turn
        val accel = state == MochiState.ACCELERATING
        currentDepthScale = ease(currentDepthScale, if (accel) 1f - 0.08f * min(cfg.lean, 1.5f) else 1f, 8f, sdt)
        currentDepthShiftY = ease(currentDepthShiftY, if (accel) 16f * s * cfg.lean else 0f, 8f, sdt)
        currentTilt = ease(currentTilt, (-latG * 2.2f * leanK).coerceIn(-20f, 20f), 8f, sdt)

        // Idle bob and brake shiver
        idleTick += sdt * 3.2f
        shakeTick += dt
        val bobY = sin(idleTick) * 4f * s * cfg.bob
        var shakeX = 0f
        var shakeY = 0f
        if (cfg.shake && shockWeight > 0.05f) {
            val mag = shockWeight * 8f * s * veh.shake
            shakeX = sin(shakeTick * 61f) * mag
            shakeY = sin(shakeTick * 47f + 1.3f) * mag * 0.6f
        }

        canvas.save()
        canvas.translate(cx + shakeX, cy + bobY + currentDepthShiftY + shakeY)
        canvas.rotate(currentTilt)
        canvas.scale(currentDepthScale, currentDepthScale)

        val eyeShiftX = (-latG * 5f * s * leanK).coerceIn(-45f * s, 45f * s)
        val eyeShiftY = (longG * 4f * s * leanK).coerceIn(-30f * s, 30f * s)
        val spacing = 85f * s
        val lx = -spacing + eyeShiftX
        val rx = spacing + eyeShiftX
        val ey = eyeShiftY

        // Shock rings
        if (shockWeight > 0.01f) {
            eyeStroke.strokeWidth = 8f * s
            eyeStroke.alpha = (shockWeight * (1f - squintWeight) * 255).toInt().coerceIn(0, 255)
            canvas.drawCircle(lx, ey, 46f * s, eyeStroke)
            canvas.drawCircle(rx, ey, 46f * s, eyeStroke)
        }

        // Eyes (shape depends on style)
        val eyeAlpha = ((1f - squintWeight) * (1f - blinkFactor) * 255).toInt().coerceIn(0, 255)
        if (eyeAlpha > 0) {
            val r = (28f * (1f - shockWeight) + 11f * shockWeight) * s
            eyeFill.alpha = eyeAlpha
            drawEye(canvas, lx, ey, r, cfg.eyeStyle)
            drawEye(canvas, rx, ey, r, cfg.eyeStyle)

            // Side-glance pupil dots
            if (abs(lookXWeight) > 0.02f && shockWeight < 0.6f) {
                val off = lookXWeight * 10f * s
                dotPaint.alpha = (abs(lookXWeight) * (1f - shockWeight) * eyeAlpha).toInt().coerceIn(0, 255)
                canvas.drawCircle(lx + off, ey, 8f * s, dotPaint)
                canvas.drawCircle(rx + off, ey, 8f * s, dotPaint)
            }
        }

        // Blink slits
        if (blinkFactor > 0.01f) {
            eyeStroke.strokeWidth = 9f * s
            eyeStroke.alpha = (blinkFactor * 255).toInt().coerceIn(0, 255)
            canvas.drawLine(lx - 25f * s, ey, lx + 25f * s, ey, eyeStroke)
            canvas.drawLine(rx - 25f * s, ey, rx + 25f * s, ey, eyeStroke)
        }

        // Joyful "^ ^"
        if (squintWeight > 0.01f) {
            val ew = 30f * s
            val eh = 22f * s
            eyeStroke.strokeWidth = 10f * s
            eyeStroke.alpha = (squintWeight * 255).toInt().coerceIn(0, 255)

            leftEyePath.reset()
            leftEyePath.moveTo(lx - ew, ey + eh * 0.5f)
            leftEyePath.lineTo(lx, ey - eh * 0.5f)
            leftEyePath.lineTo(lx + ew, ey + eh * 0.5f)

            rightEyePath.reset()
            rightEyePath.moveTo(rx - ew, ey + eh * 0.5f)
            rightEyePath.lineTo(rx, ey - eh * 0.5f)
            rightEyePath.lineTo(rx + ew, ey + eh * 0.5f)

            canvas.drawPath(leftEyePath, eyeStroke)
            canvas.drawPath(rightEyePath, eyeStroke)
        }

        // Mouth (optional)
        if (cfg.mouthStyle != 0) {
            val mx = eyeShiftX
            val my = ey + 62f * s
            eyeStroke.strokeWidth = 6f * s

            val smileAlpha = ((1f - shockWeight) * 255).toInt().coerceIn(0, 255)
            if (smileAlpha > 0) {
                eyeStroke.alpha = smileAlpha
                val grin = 1f + 0.8f * squintWeight
                mouthPath.reset()
                if (cfg.mouthStyle == 2) {
                    mouthPath.moveTo(mx - 26f * s, my)
                    mouthPath.quadTo(mx - 13f * s, my + 16f * s * grin, mx, my)
                    mouthPath.quadTo(mx + 13f * s, my + 16f * s * grin, mx + 26f * s, my)
                } else {
                    mouthPath.moveTo(mx - 18f * s, my)
                    mouthPath.quadTo(mx, my + 20f * s * grin, mx + 18f * s, my)
                }
                canvas.drawPath(mouthPath, eyeStroke)
            }
            if (shockWeight > 0.02f) {
                eyeStroke.alpha = (shockWeight * 255).toInt().coerceIn(0, 255)
                canvas.drawCircle(mx, my + 6f * s, 10f * s * shockWeight, eyeStroke)
            }
        }

        // Cheeks
        if (cfg.showBlush) {
            cheekPaint.alpha = ((1f - shockWeight * 0.4f) * 255).toInt().coerceIn(0, 255)
            canvas.drawCircle(lx - 35f * s, ey + 38f * s, 14f * s, cheekPaint)
            canvas.drawCircle(rx + 35f * s, ey + 38f * s, 14f * s, cheekPaint)
        }

        canvas.restore()
    }
}
